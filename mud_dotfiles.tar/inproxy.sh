#!/usr/bin/env bash


function activate_proxy {

  export HTTPS_PROXY=http://172.19.1.41:8080
  export HTTP_PROXY=http://172.19.1.41:8080
  export FTP_PROXY=http://172.19.1.41:8080
  
}

activate_proxy
unset activate_proxy